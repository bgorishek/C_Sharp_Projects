﻿using System;

/// <summary>
/// Midterm Exam for MIS 3013 2020
/// </summary>
/// 
/// <author>
/// Brian Gorishek
/// </author>
namespace Problem1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter word 1:");
            string word1 = Console.ReadLine();

            Console.WriteLine("Please enter word 2:");
            string word2 = Console.ReadLine();

            int num1 = word1.Length;
            int num2 = word2.Length;

            Console.WriteLine("Your first word has " + num1.ToString("F1") + " letters, and your second word has " + num2.ToString("F1") + " letters.");

            int solution = 0;
            if (num1 >= num2)
            {
                solution = num1 - num2;
                Console.WriteLine(num1.ToString("F1") + " - " + num2.ToString("F1") + " =");
                Console.WriteLine(solution.ToString("F1"));
            }
            else
            {
                solution = num2 - num1;
                Console.WriteLine(num2.ToString("F1") + " - " + num1.ToString("F1") + " =");
                Console.WriteLine(solution.ToString("F1"));
            }
        }
    }
}
