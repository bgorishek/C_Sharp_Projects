﻿using System;

/// <summary>
/// Midterm Exam for MIS 3013 2020
/// </summary>
/// 
/// <author>
/// Brian Gorishek
/// </author>
namespace Problem2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello nephew!");
            Console.WriteLine("How many coins do you have total?");
            string answer = Console.ReadLine();
            int idk;

            //do
            //{
            //    Console.WriteLine("Silly nephew, that's a fruit. Please enter a number:");
            //    answer = Console.ReadLine();
            //} while (int.TryParse(answer, out idk) == false);
            while (int.TryParse(answer, out idk) == false)
            {
                Console.WriteLine("Silly nephew, that's a fruit. Please enter a number:");
                answer = Console.ReadLine();
            }
            int numCoins = Convert.ToInt32(answer);

            double change = 0;

            for (int i = 0; i < numCoins; i++)
            {
                Console.WriteLine("What type of coin is coin#" + (i + 1) + "?");
                string coinType = Console.ReadLine().ToLower();

                if (coinType == "a penny")
                {
                    change += 0.01;
                }
                else if (coinType == "a nickel")
                {
                    change += 0.05;
                }
                else if (coinType == "a dime")
                {
                    change += 0.10;
                }
                else if (coinType == "a quarter")
                {
                    change += 0.25;
                }
                else
                {
                    Console.WriteLine("ERROR");
                    Environment.Exit(-1);
                }
            }
               // Console.WriteLine("What type of coin is coin#" + i + "?");
               // string coinType = Console.ReadLine().ToLower();

               // double change = 0;
               // double value = 0;
               // if (coinType == "a penny")
               // {
               //     change += 0.01;
               // }
               // else if (coinType == "a nickel")
               // {
               //     change += 0.05;
               // }
               //else if (coinType == "a dime")
               // {
               //     change += 0.10;
               // }
               // else if (coinType == "a quarter")
               // {
               //  change += 0.25;
               // }
               // else
               // {
               //     Console.WriteLine("ERROR");
               //     Environment.Exit(-1);
               // }

            Console.WriteLine("You have a total of: " + change.ToString("C4"));
            Console.WriteLine("Developed by Brian Gorishek 3/10/21");
        }
    }
}
