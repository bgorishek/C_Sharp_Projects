﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Homework8ClassesExtended
{
    class Program
    {
        
        static void Main(string[] args)
        {
            string apptDate = "";
            string firstName = "";
            char midInitial = '\0';
            string lastName = "";
            int id = 0;
            bool fluVaccine = false;
            double weight = 0;
            List<string> meds = new List<string>();

            List<Patient> patients = new List<Patient>();



            string[] lines = File.ReadAllLines("AppointmentInformation.csv");

            foreach (string line in lines)
            {
                string[] parts = line.Split(",");

                if (line == lines[0])
                {
                    Console.WriteLine("Welcome to the Online Health Portal");
                }
                else
                {
                    
                    apptDate = parts[0];
                    firstName = parts[1];
                    midInitial = (parts[2].ToCharArray())[0];
                    lastName = parts[3];
                    id = Convert.ToInt32(parts[4]);
                    if (parts[5].ToLower()[0] == 'y')
                    {
                        fluVaccine = true;
                    }
                    else
                    {
                        fluVaccine = false;
                    }
                    weight = Convert.ToDouble(parts[6]);

                    //meds = parts[7].Split(";");

                    Patient activePatient = Patient(firstName, midInitial, lastName, id, fluVaccine, weight, meds);
                }
                
            }


        }
    }
}
