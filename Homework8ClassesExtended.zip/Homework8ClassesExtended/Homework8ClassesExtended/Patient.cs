﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Homework8ClassesExtended
{
    public class Patient
    {
        public string FirstName { get; set; }

        public char MidInitial { get; set; }

        public string LastName { get; set; }

        public int ID { get; set; }

        public bool FluVaccineYN { get; set; }

        //Supposed to be a Dictionary<DateTime, double> but that doesn't really make sense with the data set
        public string ApptDate { get; set; }
        public double Weight { get; set; }

        public List<string> Prescriptions { get; set; }

        public Patient()
        {
            FirstName = "";
            MidInitial = '\0';
            LastName = "";
            ID = 0;
            FluVaccineYN = false;
            ApptDate = "";
            Weight = 0;
            Prescriptions = new List<string>();
        }

        public Patient(int patID)
        {
            FirstName = "";
            MidInitial = '\0';
            LastName = "";
            ID = patID;
            FluVaccineYN = false;
            ApptDate = "";
            Weight = 0;
            Prescriptions = new List<string>();
        }

        public Patient(string firstName, char midInit, string lastName)
        {
            FirstName = firstName;
            MidInitial = midInit;
            LastName = lastName;
            ID = 0;
            FluVaccineYN = false;
            ApptDate = "";
            Weight = 0;
            Prescriptions = new List<string>();
        }

        public Patient(string firstName, char midInit, string lastName, int id, bool fluVaccineYN, double weight, List<string> meds)
        {
            FirstName = firstName;
            MidInitial = midInit;
            LastName = lastName;
            ID = id;
            FluVaccineYN = fluVaccineYN;
            Weight = weight;
            Prescriptions = meds;
        }

        public override string ToString()
        {
            string output = "";
            if (FluVaccineYN == true)
            {
                output = (LastName + ", " + FirstName + " " + MidInitial + ". (" + ID + ") Flu Vaccine: YES");
            }
            else
            {
                output = (LastName + ", " + FirstName + " " + MidInitial + ". (" + ID + ") Flu Vaccine: NO");
            }
            return output;
        }

        public void DisplayMed()
        {
            foreach (string med in Prescriptions)
            {
                Console.WriteLine(med);
            }
        }

        public void AdministerVaccine()
        {
            FluVaccineYN = true;
            Console.WriteLine("Patient " + LastName + ", " + FirstName + " " + MidInitial + ". has been administered a vaccine");
        }

    }
}
