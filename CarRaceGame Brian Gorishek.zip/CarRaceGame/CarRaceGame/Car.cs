﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarRaceGame
{
    public class Car
    {

        public string Name { get; set; }

        public double Speed { get; set; }

        public double Accel { get; set; }

        public double Brake { get; set; }

        public double Launch { get; set; }

        public double Hand { get; set; }

        public Car()
        {
            Name = "";
            Speed = 0;
            Accel = 0;
            Brake = 0;
            Launch = 0;
            Hand = 0;
        }

        public Car(string name, double speed, double accel, double brake, double hand, double launch)
        {
            Name = name;
            Speed = speed;
            Accel = accel;
            Brake = brake;
            Launch = launch;
            Hand = hand;
        }

        public void Tune()
        {
            Speed++;
            Accel++;
            Brake++;
            Launch++;
            Hand++;
            return;
        }

        public override string ToString()
        {
            string output = (Name + " \n SPD: " + Speed + ", \tACC: " + Accel + ", \tBRK: " + Brake + ", \tHND: " + Hand + ", \tLAU: " + Launch);
            return output;
        }

    }
}
