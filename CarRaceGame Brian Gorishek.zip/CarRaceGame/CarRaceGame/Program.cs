﻿using System;
using System.Collections.Generic;

namespace CarRaceGame
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the Racing Game v1.0 by Brian Gorishek");
            string answer = "";

            //Creating Drivers
            Driver bob = new Driver("Bob", 0.10, 10);
            //Console.WriteLine("\n1. " + bob.ToString());

            Driver john = new Driver("John", -0.10, 1);
            //Console.WriteLine("\n2. " + john.ToString());

            Driver ted = new Driver("Ted", 0.05, 7);
            //Console.WriteLine("\n3. " + ted.ToString());

            Driver carla = new Driver("Carla", 0, 4);
            //Console.WriteLine("\n4. " + carla.ToString());

            Driver reese = new Driver("Reese", -0.05, 3);
            //Console.WriteLine("\n5. " + reese.ToString());

            do
            {
                Console.WriteLine("\nChoose your car: (Enter a number between 1 and 5)\nSPD = Speed\tACC = Acceleration\tBRK = Braking\tHND = Handling\tLAU = Launch\n");

                //Creating Cars
                Car mclaren = new Car("Mclaren 720S Coupe", 8.6, 8.2, 9.4, 9.2, 9.5);
                Console.WriteLine("1. " + mclaren.ToString());

                Car pista = new Car("Ferrari 488 Pista", 8.0, 8.8, 9.6, 9.0, 9.4);
                Console.WriteLine("\n2. " + pista.ToString());

                Car lambo = new Car("Lamborghini Aventador Superveloce", 8.7, 9.5, 9.1, 8.7, 10);
                Console.WriteLine("\n3. " + lambo.ToString());

                Car porsche = new Car("Porsche 911 GT3 RS", 8.3, 8.3, 10, 9.7, 9.6);
                Console.WriteLine("\n4. " + porsche.ToString());

                Car venom = new Car("Hennessey Venom GT", 10, 8.0, 8.7, 8.3, 9.1);
                Console.WriteLine("\n5. " + venom.ToString());

                Car activeCar = new Car();
                answer = Console.ReadLine();

                List<Car> carList = new List<Car>();
                carList.Add(mclaren);
                carList.Add(pista);
                carList.Add(lambo);
                carList.Add(porsche);
                carList.Add(venom);

                do
                {
                    if (answer == "1")
                    {
                        activeCar = mclaren;
                    }
                    else if (answer == "2")
                    {
                        activeCar = pista;
                    }
                    else if (answer == "3")
                    {
                        activeCar = lambo;
                    }
                    else if (answer == "4")
                    {
                        activeCar = porsche;
                    }
                    else if (answer == "5")
                    {
                        activeCar = venom;
                    }
                    else
                    {
                        Console.WriteLine("Please enter a valid integer between 1 and 5 corresponding to the car you would like:");
                        answer = Console.ReadLine();
                    }
                } while (answer != "1" && answer != "2" && answer != "3" && answer != "4" && answer != "5");


                Console.WriteLine("You have selected the " + activeCar.Name + ", \n\nPlease choose your driver: (Enter a number between 1 and 5)");

                ////Creating Drivers
                //Driver bob = new Driver("Bob", 0.10, 10);
                Console.WriteLine("\n1. " + bob.ToString());

                //Driver john = new Driver("John", -0.10, 1);
                Console.WriteLine("\n2. " + john.ToString());

                //Driver ted = new Driver("Ted", 0.05, 7);
                Console.WriteLine("\n3. " + ted.ToString());

                //Driver carla = new Driver("Carla", 0, 4);
                Console.WriteLine("\n4. " + carla.ToString());

                //Driver reese = new Driver("Reese", -0.05, 3);
                Console.WriteLine("\n5. " + reese.ToString());

                List<Driver> driverList = new List<Driver>();
                driverList.Add(bob);
                driverList.Add(ted);
                driverList.Add(john);
                driverList.Add(carla);
                driverList.Add(reese);

                Driver activeDriver = new Driver();
                answer = Console.ReadLine();
                do
                {
                    if (answer == "1")
                    {
                        activeDriver = bob;
                    }
                    else if (answer == "2")
                    {
                        activeDriver = john;
                    }
                    else if (answer == "3")
                    {
                        activeDriver = ted;
                    }
                    else if (answer == "4")
                    {
                        activeDriver = carla;
                    }
                    else if (answer == "5")
                    {
                        activeDriver = reese;
                    }
                    else
                    {
                        Console.WriteLine("Please enter a valid integer between 1 and 5 corresponding to the driver you would like:");
                        answer = Console.ReadLine();
                    }
                } while (answer != "1" && answer != "2" && answer != "3" && answer != "4" && answer != "5");

                Console.WriteLine("You have selected " + activeDriver.Name + ", \n\nPlease choose the track: (Enter a number between 1 and 5)");

                List<Driver> unusedDrivers = new List<Driver>();

                foreach (Driver driver in driverList)
                {
                    if (driver != activeDriver)
                    {
                        unusedDrivers.Add(driver);
                    }
                }

                //Creating Tracks
                Track indie = new Track("Indianapolis Motor Speedway", 2.50, 4, 4);
                Console.WriteLine("\n1. " + indie.ToString());

                Track spa = new Track("Circuit de Spa-Francorchamps", 4.35, 20, 4);
                Console.WriteLine("\n2. " + spa.ToString());

                Track laguna = new Track("Mazda Raceway Laguna Seca", 2.25, 11, 2);
                Console.WriteLine("\n3. " + laguna.ToString());

                Track yas = new Track("Yas Marina Circuit", 3.45, 21, 3);
                Console.WriteLine("\n4. " + yas.ToString());

                Track nurburg = new Track("Nurburgring Nordschleife", 12.95, 154, 7);
                Console.WriteLine("\n5. " + nurburg.ToString());

                Track activeTrack = new Track();
                answer = Console.ReadLine();
                do
                {
                    if (answer == "1")
                    {
                        activeTrack = indie;
                    }
                    else if (answer == "2")
                    {
                        activeTrack = spa;
                    }
                    else if (answer == "3")
                    {
                        activeTrack = laguna;
                    }
                    else if (answer == "4")
                    {
                        activeTrack = yas;
                    }
                    else if (answer == "5")
                    {
                        activeTrack = nurburg;
                    }
                    else
                    {
                        Console.WriteLine("Please enter a valid integer between 1 and 5 corresponding to the track you would like:");
                        answer = Console.ReadLine();
                    }
                } while (answer != "1" && answer != "2" && answer != "3" && answer != "4" && answer != "5");

                Console.WriteLine("You have selected " + activeTrack.Name);
                Console.WriteLine("On a scale of 1-5, 1 being clear skies and 5 being a thunderstorm, how is the weather at " + activeTrack.Name + " today?");

                int weather = Convert.ToInt32(Console.ReadLine());


                Console.WriteLine("Randomly assigning drivers to cars...");

                Random rand = new Random();
                int randNo = rand.Next(0, 5);

                foreach (Driver unusedDriver in unusedDrivers)
                {
                    unusedDriver.RandNo = rand.Next(0, 5);
                    Console.WriteLine(unusedDriver.Name + " is driving a " + carList[unusedDriver.RandNo].Name);
                }

                Console.WriteLine("\nGetting ready to race...\nWould you like to tune your car to improve its stats? (Y/N)");

                answer = Console.ReadLine();

                if (answer.ToLower()[0] == 'y')
                {
                    activeCar.Tune();
                    Console.WriteLine("Your " + activeCar.Name + " is now tuned and faster\nGet ready to race!");
                }
                else
                {
                    Console.WriteLine("Who needs a tune when you can win the old fashioned way?\nGet ready to race!");
                }


                Console.WriteLine("\n\nRacing...\n\n\nRacing...\n\n\nRacing...\n\n\nFinished!\n");

                foreach (Driver racer in driverList)
                {
                    racer.RaceTime = ((70 - 6 * carList[racer.RandNo].Speed) * activeTrack.Distance +
                        (110 - carList[racer.RandNo].Accel * 3 - carList[racer.RandNo].Brake * 3 - carList[racer.RandNo].Hand * 4) * activeTrack.Turns +
                        (10 - carList[racer.RandNo].Launch) +
                        (weather * (10 - carList[racer.RandNo].Hand)) +
                        (65 - carList[racer.RandNo].Speed * 4 - carList[racer.RandNo].Accel * 2) * activeTrack.Straightaways)
                        * (1 - racer.Skill);
                }

                List<double> raceTimes = new List<double>();
                Console.WriteLine("Results:");
                foreach (Driver driverx in driverList)
                {
                    raceTimes.Add(driverx.RaceTime);
                    Console.WriteLine(driverx.Name + " finished in " + driverx.RaceTime.ToString("F1"));
                }
                double minTime = raceTimes[0];
                foreach (var time in raceTimes)
                {
                    if (time < minTime)
                    {
                        minTime = time;
                    }
                }

                foreach (Driver driver1 in driverList)
                {
                    if (driver1.RaceTime == minTime)
                    {
                        Console.WriteLine("\n" + driver1.Name + " is the winner!");

                        if (driver1 == activeDriver)
                        {
                            Console.WriteLine("Congratulations you choose the winner!");
                        }
                        driver1.Win();
                        Console.WriteLine(driver1.Name + " now has " + driver1.Wins + " wins.");
                    }
                }



                Console.WriteLine("Would you like to race again? (Y/N)");
                answer = Console.ReadLine();

            } while (answer.ToLower()[0] == 'y');

            if (answer.ToLower()[0] == 'n')
            {
                Console.WriteLine("\n\nThank you for playing! Have a good day!\n\nDeveloped by Brian Gorishek 5/3/2021");
            }

        }
    }
}
