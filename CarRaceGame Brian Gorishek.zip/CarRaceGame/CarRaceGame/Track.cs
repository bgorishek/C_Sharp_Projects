﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarRaceGame
{
    public class Track
    {

        public string Name { get; set; }

        public double Distance { get; set; }

        public int Turns { get; set; }

        public int Straightaways { get; set; }

        public Track()
        {
            Name = "";
            Distance = 0;
            Turns = 0;
            Straightaways = 0;
        }

        public Track(string name, double distance, int turns, int straightaways)
        {
            Name = name;
            Distance = distance;
            Turns = turns;
            Straightaways = straightaways;
        }

        public override string ToString()
        {
            string output = (Name + "\n Distance: " + Distance + " Miles\t\tTurns:" + Turns + "  \t\tStraightaways: " + Straightaways);
            return output;
        }


    }
}
