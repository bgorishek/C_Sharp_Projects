﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarRaceGame
{
    public class Driver
    {

        public string Name { get; set; }

        public double Skill { get; set; }

        public int Wins { get; set; }

        public int RandNo { get; set; }

        public double RaceTime { get; set; }

        public Driver()
        {
            Name = "";
            Skill = 0;
            Wins = 0;
        }

        public Driver(string name, double skill, int wins)
        {
            Name = name;
            Skill = skill;
            Wins = wins;
        }


        public override string ToString()
        {
            string output = (Name + "\n Skill Factor: " + Skill + "\t Wins: " + Wins);
            return output;
        }

        public void Win()
        {
            Wins++;
        }


    }
}
