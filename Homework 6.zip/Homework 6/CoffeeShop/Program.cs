﻿using System;

namespace CoffeeShop
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Coffee Shop Menu\n Fresh Coffee ... \t$2.25 \n Cafe au Lait ... \t$3.72 \n Latte ... \t\t$4.03 \n Hot Chocolate ... \t$3.51 \n Pumpkin Spice ... \t$7.30");

            string start = GetMenu();
            Console.WriteLine(start);
            Console.WriteLine("What would you like to order today?");
            string answer = Console.ReadLine();

            double cost = CalculatePrice(answer);

            Console.WriteLine("Would you like to order another item?");
            answer = Console.ReadLine();
            if (answer.ToLower()[0] == 'y')
            {
                do
                {
                    Console.WriteLine("What would you like?");
                    answer = Console.ReadLine();
                    cost += CalculatePrice(answer);
                    Console.WriteLine("Would you like to order another item?");
                    answer = Console.ReadLine();
                } while (answer.ToLower()[0] == 'y');
            }

            
            //Console.WriteLine(cost.ToString("C2"));

            ShowReceipt(cost);
            Console.WriteLine("Thank you for playing, Goodbye!");
        }

        static string GetMenu()
        {
            string output = "Coffee Shop Menu\n Fresh Coffee ... \t$2.25 \n Cafe au Lait ... \t$3.72 \n Latte ... \t\t$4.03 \n Hot Chocolate ... \t$3.51 \n Pumpkin Spice ... \t$7.30";

            return output;
        }

        static double CalculatePrice(string input)
        {
            double price = 0;
            if (input.ToLower() == "fresh coffee" | input.ToLower() == "coffee")
            {
                price = 2.25;
                return price;
            }
            else if (input.ToLower() == "cafe au lait")
            {
                price = 3.72;
                return price;
            }
            else if (input.ToLower() == "latte")
            {
                price = 4.03;
                return price;
            }
            else if (input.ToLower() == "hot chocolate")
            {
                price = 3.51;
                return price;
            }
            else if (input.ToLower() == "pumpkin spice" | input.ToLower() == "psl")
            {
                price = 7.30;
                return price;
            }
            else
            {
                return price;
            }
        }

        static void ShowReceipt(double input1)
        {
            double tax = 0.085;
            Console.WriteLine("Subtotal: \t\t" + input1.ToString("C2"));
            double taxExp = tax * input1;
            Console.WriteLine("Tax: \t\t\t" + taxExp.ToString("C2"));

            Console.WriteLine("Total: \t\t\t" + (input1 + taxExp).ToString("C2"));
        }
    }
}
